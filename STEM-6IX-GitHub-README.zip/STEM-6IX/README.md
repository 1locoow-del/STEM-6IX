# STEM 6IX

![Different minds, one journey, countless memories](assets/stem6ix-quote.jpg)

## Different minds, one journey, countless memories.

Welcome to **STEM 6IX** — a collection of shared files and memories.

## Collection

1. [Open file 1](https://drive.google.com/file/d/13CtWnuDAi7Iul0U_4ZjZ8fZO02UDP_d7/view?usp=drivesdk)
2. [Open file 2](https://drive.google.com/file/d/16GIlE9dHgGxN8Rrs6tHPXXtmpXVxbiVp/view?usp=drivesdk)
3. [Open file 3](https://drive.google.com/file/d/1yM1aowTpJFwfZ6m0Ni36c6U0MHR5Ol17/view?usp=drivesdk)
4. [Open file 4](https://drive.google.com/file/d/1-_U-1vljw7irDPD8mocnCERtfssFAWgq/view?usp=drivesdk)
5. [Open file 5](https://drive.google.com/file/d/1E-AMf46vUz5Ti4htfKfxEdSUMZ7ITlrs/view?usp=drivesdk)
6. [Open file 6](https://drive.google.com/file/d/1lzzwNCtnL9kOnWzChhHJnankExUKJK12/view?usp=drivesdk)
7. [Open file 7](https://drive.google.com/file/d/1YdnljI7pd-6VoeuXdgCGfvammS2WRsVF/view?usp=drivesdk)
8. [Open file 8](https://drive.google.com/file/d/1NtHdxo688MTnma7IdGZhdMXSNu8ABG8t/view?usp=drivesdk)
9. [Open file 9](https://drive.google.com/file/d/1oiXAjJhbYNj6W2oxEYIGUG5kHXWEd71U/view?usp=drivesdk)
10. [Open file 10](https://drive.google.com/file/d/13tWALAIsZsJOu_9hgzX-b10lE1__Xovo/view?usp=drivesdk)
11. [Open file 11](https://drive.google.com/file/d/1CyAbicX13pvQSLQ59zy7HyQ2C0zAxm7k/view?usp=drivesdk)
12. [Open file 12](https://drive.google.com/file/d/1mlq0b4DGbzWZ2BOW9BUmQIIMmMjK0tTh/view?usp=drivesdk)
13. [Open file 13](https://drive.google.com/file/d/1jv5Kn_Unv0xPk2-zbtZ15UJhB_BMYxnw/view?usp=drivesdk)
14. [Open file 14](https://drive.google.com/file/d/1athkgYqZ32oNdeadAg90z-W5P_rN_l4N/view?usp=drivesdk)
15. [Open file 15](https://drive.google.com/file/d/18aEPgSld1QfzPIDAEUR1Wln-rEli-M8a/view?usp=drivesdk)
16. [Open file 16](https://drive.google.com/file/d/1uHkUUl5lXwjNikQEjfXoGQT8x8E3QU32/view?usp=drivesdk)
17. [Open file 17](https://drive.google.com/file/d/1iUhzQK1BdoeHcf8lEd8el-wdTkO3LqI7/view?usp=drivesdk)
18. [Open file 18](https://drive.google.com/file/d/1yubmDt8LYl7JMPUamQgGa9emgZPJ4-T8/view?usp=drivesdk)
19. [Open file 19](https://drive.google.com/file/d/1-kIUyqYXVOMYsaoFp54RKoPOZKyqSw0a/view?usp=drivesdk)
20. [Open file 20](https://drive.google.com/file/d/1m2Is9FCzlkJCjr78b--SzfbVWdqab_gS/view?usp=drivesdk)
21. [Open file 21](https://drive.google.com/file/d/1hlAWUVUL3Sq5rBI8Nqs1g6p-yVHFbYSx/view?usp=drivesdk)
22. [Open file 22](https://drive.google.com/file/d/14819qoZMhKmW1PlR7l7NusIRc2xMZ69N/view?usp=drivesdk)
23. [Open file 23](https://drive.google.com/file/d/17jNWYJ0UzhLNTqQe-wl4oDmF6tUKVdNt/view?usp=drivesdk)
24. [Open file 24](https://drive.google.com/file/d/1BHw7nuW3QVF6XfQMsGmdkqvbQDMMlEZv/view?usp=drivesdk)
25. [Open file 25](https://drive.google.com/file/d/18_cx-T9o-OmC96TNDVBaznNXJdCLVeoO/view?usp=drivesdk)
26. [Open file 26](https://drive.google.com/file/d/1mpBTFkk8jygZscGYnvabwJi2sXOtMZJ6/view?usp=drivesdk)

---

*Different minds, one journey, countless memories.*
